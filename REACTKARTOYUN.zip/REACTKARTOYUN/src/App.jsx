import { useState, useEffect } from "react";
import Card from "./components/Card";

function App() {
  const defaultCards = [
    { id: 1, path: "/img/tavsan.jpeg", matched: false },
    { id: 2, path: "/img/bukalemun.jpeg", matched: false },
    { id: 3, path: "/img/kirpi.jpeg", matched: false },
    { id: 4, path: "/img/civciv.jpeg", matched: false },
    { id: 5, path: "/img/KomodoEjderi.jpeg", matched: false },
    { id: 6, path: "/img/sincap.jpeg", matched: false },
  ];

  const [isGameOver, setIsGameOver] = useState(false);
  const [cards, setCards] = useState([]);
  const [selectedOne, setSelectedOne] = useState(null);
  const [selectedTwo, setSelectedTwo] = useState(null);
  const [message, setMessage] = useState("Oyuna Başla!");
  const [score, setScore] = useState(0); // Skoru tutan durum

  const prepareCards = () => {
    const shuffledCards = [...defaultCards, ...defaultCards].sort(() => Math.random() - 0.5);
    setCards(shuffledCards);
    resetSelection();
    setMessage("İlk Kartı Seç!");
    setScore(0); // Yeni oyuna başlandığında skoru sıfırla
  };

  const handleSelected = (card) => {
    if (selectedOne && selectedTwo) return;

    if (!selectedOne) {
      setSelectedOne(card);
      setMessage("İkinci Kartı Seç!");
    } else {
      setSelectedTwo(card);
      setMessage("Kartlar Kontrol Ediliyor...");
    }
  };

  useEffect(() => {
    if (selectedOne && selectedTwo) {
      if (selectedOne.path === selectedTwo.path) {
        setCards((prevCards) =>
          prevCards.map((card) =>
            card.path === selectedOne.path ? { ...card, matched: true } : card
          )
        );
        setMessage("Eşleşme Bulundu! Yeni Kart Seç!");
        setScore((prevScore) => prevScore + 20); //  20 puan ekle
        resetSelection();

        if (cards.every((card) => card.matched || card.path === selectedOne.path)) {
          setIsGameOver(true);
        }
      } else {
        setTimeout(() => {
          setMessage("Kartlar Eşleşmedi! Tekrar Dene!");
          setScore((prevScore) => prevScore - 5); // Yanlış eşleşme için 5 puan sil
          resetSelection();
        }, 1000);
      }
    }
  }, [selectedTwo]);

  const resetSelection = () => {
    setSelectedOne(null);
    setSelectedTwo(null);

    setCards((prevCards) =>
      prevCards.map((card) =>
        card.matched ? card : { ...card, isFlipped: false }
      )
    );
  };

  useEffect(() => {
    prepareCards();
  }, []);

  useEffect(() => {
    if (isGameOver) {
      const timer = setTimeout(() => {
        setIsGameOver(false);
      }, 5000);

      return () => clearTimeout(timer);
    }
  }, [isGameOver]);

  return (
    <section className="flex flex-col items-center justify-center gap-10 mt-20">
      {!isGameOver && (
        <>
          <h1 className="text-3xl font-semibold text-center text-black">Eşini Tahmin Et</h1>
          <button
            className="bg-[#FF7D29] px-3 py-2 rounded hover:translate-y-2 transition-all text-center text-white"
            onClick={prepareCards}
          >
            Oyunu Başlat
          </button>
          <h2>{message}</h2>
          <h3>Skor: {score}</h3> {/* Skoru ekrana yazdır */}
          <div className="grid grid-cols-4 gap-5 mt-10">
            {cards.map((card, index) => (
              <Card
                key={index}
                card={card}
                handleSelected={handleSelected}
                isFlipped={selectedOne === card || selectedTwo === card || card.matched}
                disabled={selectedOne && selectedTwo}
              />
            ))}
          </div>
        </>
      )}
      {isGameOver && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-100">
          <h1 className="text-4xl text-dark-red animate-bounce">Tebrikler! Oyunu Tamamladınız!</h1>
        </div>
      )}
      <footer
        style={{
          position: 'relative',
          width: '100%',
          padding: '40px 0',
          marginTop: '40px',
          marginBottom: '20px',
          textAlign: 'center',
          color: 'rgb(46, 1, 1)',
          fontSize: '20px',
          backgroundColor: 'transparent',
        }}
      >
        Bu Reactla yaptığım ilk oyun..
      </footer>
    </section>
  );
}

export default App;
