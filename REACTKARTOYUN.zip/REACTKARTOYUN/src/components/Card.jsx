import React from "react";

const Card = ({ card, handleSelected, isFlipped, disabled }) => {
  const handleClick = () => {
    if (!disabled && !isFlipped) {
      handleSelected(card);
    }
  };

  return (
    <div
      className={`relative w-[150px] h-[150px] transition-transform duration-500 ${card.matched ? "transform scale-0" : ""
        }`}
      onClick={handleClick}
    >
      <img
        src={card.path}
        className={`absolute inset-0 w-full h-full object-cover transition-transform duration-500 ${isFlipped ? "" : "opacity-0"
          }`}
      />
      <img
        src="/img/kapak.jpeg"
        className={`absolute inset-0 w-full h-full object-cover cursor-pointer transition-transform duration-500 ${isFlipped ? "opacity-0" : ""
          }`}
      />
    </div>
  );
};

export default Card;
